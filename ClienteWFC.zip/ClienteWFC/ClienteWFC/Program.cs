﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        ServiceReference1.WFCServiceClient client = new ServiceReference1.WFCServiceClient();

        ServiceReference1.LoginRequest loginRequest = new ServiceReference1.LoginRequest
        {
             username = "Morales",
             password = "Morales204"
        };
        
        ServiceReference1.LoginResponse response = client.Login(loginRequest);
        Console.WriteLine();
        // Check if the login was successful
        if (response.LoginResult)
        {
            Console.WriteLine("Login successful");
        }
        else
        {
            Console.WriteLine("Login failed");
        }

        client.Close();


    }
}